tinyMCE.addI18n("en.polls", {
	insert_poll : 'Insert Poll'
});